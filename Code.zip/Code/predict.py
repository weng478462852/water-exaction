from __future__ import print_function
import os
import cv2 as cv
import matplotlib.pyplot as plt
import torch
from torch.autograd import Variable
from PIL import Image
import numpy as np
from models.u_net import UNet
from models.u_netoc import UNetOC
from models.seg_net import Segnet
from data_loader.dataset import input_transform, colorize_mask
import evo
import time

# model = Segnet(3,2)
# model_path = './checkpoint/Segnet/model/netG_final.pth'

# model = UNet(3, 2)
# model_path = 'C:/Users/Administrator/Desktop/final/Unet/model/netG_final.pth'

model=UNetOC(3,2)
model_path = 'C:/Users/Administrator/Desktop/test/OCNet_epoch5/oc模型e2/netG_final.pth'


model.load_state_dict(torch.load(model_path, map_location='cpu'))


predict_image_path = 'C:/Users/Administrator/Desktop/水体提取/water exaction/Semantic-segmentation-master/Training Set/presrc/'
predict_folders = os.listdir(predict_image_path )
save_image_path='C:/Users/Administrator/Desktop/test/predictUOC/'
save_folders = os.listdir(save_image_path)

start = time.time()
for folder in predict_folders:
    # 获取图片路径
    test_folder_path = os.path.join(predict_image_path, folder)
    save_folder_path = os.path.join(save_image_path, folder)

    test_image = Image.open(test_folder_path ).convert('RGB')
    img = input_transform(test_image)
    img = img.unsqueeze(0)
    img = Variable(img)
    pred_image = model(img)
    predictions = pred_image.data.max(1)[1].squeeze_(1).cpu().numpy()
    prediction = predictions[0]
    predictions_color = colorize_mask(prediction)
    # predictions_color.show()
    predictions_color.save(save_folder_path)
    print(folder + ' worked down')

end = time.time()
print('Program processed ', end - start, 's, ', (end - start) / 60, 'min, ', (end - start) / 3600, 'h')




# test_image = Image.open(test_image_path).convert('RGB')
# print('Operating...')
# img = input_transform(test_image)
# img = img.unsqueeze(0)
# img = Variable(img)
# print(img.shape)
# pred_image = model(img)
# pred_image1=model1(img)
#
# predictions = pred_image.data.max(1)[1].squeeze_(1).cpu().numpy()
# prediction = predictions[0]
# predictions_color = colorize_mask(prediction)
# predictions_color.show()
# predictions_color.save('C:/Users/Administrator/Desktop/test/predict/predict_unet.png')
#
# predictions1 = pred_image1.data.max(1)[1].squeeze_(1).cpu().numpy()
# prediction1 = predictions1[0]
# predictions_color1 = colorize_mask(prediction1)
# predictions_color1.show()
# predictions_color1.save('C:/Users/Administrator/Desktop/test/predict/predict_unetoc.png')
